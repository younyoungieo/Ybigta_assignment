#과제1-1
SELECT C.CustomerID, C.CustomerName, FORMAT(SUM(P.Price * OD.Quantity), 2) AS 구매금액
FROM Customers AS C
JOIN Orders AS O
ON C.CustomerID = O.CustomerID
	JOIN OrderDetails AS OD
    ON O.OrderID = OD.OrderID
		JOIN Products AS P
        ON OD.ProductID = P.ProductID
GROUP BY C.CustomerID, C.CustomerName
ORDER BY C.CustomerID;

#과제1-2
SELECT CA.CategoryName, SUM(OD.Quantity) AS 판매량, FORMAT(SUM(P.Price * OD.Quantity), 2) AS 판매금액
FROM Categories AS CA
JOIN Products AS P
ON CA.CategoryID = P.CategoryID
	JOIN OrderDetails AS OD
    ON P.ProductID = OD.ProductID
GROUP BY CA.CategoryName
HAVING 판매량 >= 2000
ORDER BY 판매량 DESC, 판매금액 DESC;

#과제1-3
SELECT CA.CategoryName, SUM(OD.Quantity) AS 판매량, FORMAT(SUM(P.Price * OD.Quantity), 2) AS 판매금액
FROM Categories AS CA
JOIN Products AS P
ON CA.CategoryID = P.CategoryID
	JOIN OrderDetails AS OD
    ON P.ProductID = OD.ProductID
GROUP BY CA.CategoryName
HAVING 판매금액 > 
		(SELECT FORMAT(SUM(P.Price * OD.Quantity), 2) 
        FROM Categories AS CA
		JOIN Products AS P
		ON CA.CategoryID = P.CategoryID
			JOIN OrderDetails AS OD
			ON P.ProductID = OD.ProductID
        WHERE CA.CategoryName = 'Seafood'
        GROUP BY CA.CategoryName)
ORDER BY 판매량 DESC, 판매금액 DESC;

